// This file is part of the SV-Benchmarks collection of verification tasks:
// https://gitlab.com/sosy-lab/benchmarking/sv-benchmarks
//
// SPDX-FileCopyrightText: 2005-2021 University of Tartu & Technische Universität München
//
// SPDX-License-Identifier: MIT

// #include <pthread.h>
#include "racemacros.h"

int global = 0;
// pthread_mutex_t mutex1 = PTHREAD_MUTEX_INITIALIZER;
// pthread_mutex_t mutex2 = PTHREAD_MUTEX_INITIALIZER;

void munge(// pthread_mutex_t *m) {
  // pthread_mutex_lock(m);
  access_or_assert_racefree(global);
  // pthread_mutex_unlock(m);
}

void svp_simple_647_001_isr_1(void *arg) {
  munge(&mutex1);
  // return NULL;
}

void svp_simple_647_001_isr_2(void *arg) {
  munge(&mutex1);
  // return NULL;
}


int svp_simple_647_001_main(void) {
  create_threads(t1); create_threads(t2);
  join_threads(t1); join_threads(t2);
  return 0;
