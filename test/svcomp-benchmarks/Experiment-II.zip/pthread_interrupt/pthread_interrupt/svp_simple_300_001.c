// This file is part of the SV-Benchmarks collection of verification tasks:
// https://github.com/sosy-lab/sv-benchmarks
//
// SPDX-FileCopyrightText: 2011-2020 The SV-Benchmarks community
// SPDX-FileCopyrightText: The CSeq project
//
// SPDX-License-Identifier: Apache-2.0

extern void abort(void);
#include <assert.h>
void reach_error() { assert(0); }

#include <stdlib.h>
// #include <pthread.h>
#include <string.h>

void __VERIFIER_assert(int expression) { if (!expression) { ERROR: {reach_error();abort();}}; return; }

char *v;

void svp_simple_300_001_isr_1(void * arg)
{
  v = calloc(8, sizeof(char));
  // return 0;
}

void svp_simple_300_001_isr_2(void *arg)
{
  if (v) strcpy(v, "Bigshot");
  // return 0;
}


int svp_simple_300_001_main()
{
  // pthread_t t1, t2;

  // pthread_create(&t1, 0, thread1, 0);
  // pthread_create(&t2, 0, thread2, 0);
  // pthread_join(t1, 0);
  // pthread_join(t2, 0);

  __VERIFIER_assert(!v || v[0] == 'B');

  return 0;
}

